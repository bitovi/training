$.fn.tabs = function(){
	var lis = this.find('li:nth-child(n+2)');
	lis.each(function(i, li){
		var href = $(li).children().attr("href");
		$(href).hide()
	})
	this.find('li:nth-child(1)').addClass('active');
	this.find('li').bind("click", function(){
		$('.active').removeClass('active');
		var href = $(this).addClass("active").children().attr("href");
		$("div").hide()
		var $div = $(href)
		var url = $div[0].id+".html";
		
		// load page via ajax, show that div
		$.ajax({
			url: "pages/"+url,
			type: "GET",
			success : function( text ){
				$div.html( text ).show();
			},
			dataType: "text"
		})
	})
	this.find('li:first').trigger('click')
}