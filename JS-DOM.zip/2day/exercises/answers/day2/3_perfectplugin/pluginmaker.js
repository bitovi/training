$.pluginMaker = function(plugin) {

  // add the plugin function as a jQuery plugin
  $.fn[plugin.prototype.name] = function(options) {
    
    // get the arguments 
    var args = $.makeArray(arguments),
        after = args.slice(1);

    return this.each(function() {
        
      // see if we have an instance
      var instance = $.data(this, plugin.prototype.name);
      if (instance) {
            
        // call a method on the instance
        if (typeof options == "string") {
          instance[options].apply(instance, after);
        } else if (instance.update) {
            
          // call update on the instance
          instance.update.apply(instance, args);
        }
      } else {
            
        // create the plugin
        new plugin(this, options);
      }
    })
  };
};