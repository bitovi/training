Jptr = {};

Jptr.Tabs = function(el, options) {
  if (el) {
      this.init(el, options)
  }
}
  $.extend(Jptr.Tabs.prototype, {
   
    // the name of the plugin
    name: "jptr_tabs",
    
    // Sets up the tabs widget
    init: function(el, options) {
        this.element = $(el).addClass(this.name);
        this.element.bind("destroyed", 
            $.proxy(this.teardown, this));
        this.bind();
        
        // activate the first tab 
        this.activate(this.element.children("li:first"));

        // hide other tabs
        var tab = this.tab;
        this.element.children("li:gt(0)").each(function() {
            tab($(this)).hide();
        });
    },
    // bind events to this instance's methods
    bind: function() {
        this.element.delegate("li", "click", 
            $.proxy(this.tabClick, this));
    },

    // call destroy to teardown while leaving the element
    destroy: function() {
        this.element.unbind("destroyed", this.teardown);
        this.teardown();
    },
    // remove all the functionality of this tabs widget
    teardown: function() {
        $.removeData(this.element[0], this.name);
        this.element.removeClass(this.name + " tabs");
        this.unbind();
        this.element = null;
        
        var tab = this.tab;
        
        // show all other tabs
        this.element.children("li")
            .each(function() {
                tab($(this)).show()
            });
    },
    unbind: function() {
        this.element.undelegate("li","click",this.tabClick)
    },
    // helper function finds the tab for a given li
    tab: function(li) {
        return $(li.find("a").attr("href"))
    },
    // on an li click, activates new tab  
    tabClick: function(ev) {
        ev.preventDefault();
        this.activate($(ev.currentTarget))
    },

    //hides old activate tab, shows new one
    activate: function(el) {
        this.tab(this.element.find('.active')
              .removeClass('active')).hide()
        this.tab(el.addClass('active')).show();
    }
});
$.pluginMaker(Jptr.Tabs);