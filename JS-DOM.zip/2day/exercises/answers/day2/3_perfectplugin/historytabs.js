Jptr.HistoryTabs =
  function(el, options) {
    if (el) {
        this.init(el, options)
    }
};
Jptr.HistoryTabs.prototype = new Jptr.Tabs();	

$.extend(Jptr.HistoryTabs.prototype, {
  name: "jptr_history_tabs",
    
  // listen for hashchange
  bind: function() {
    $(window).bind("hashchange", 
        $.proxy(this.hashchange, this));
  },
    
  // clean up listening for hashchange.
  // this is really important
  unbind: function() {
    $(window).unbind("hashchange", this.hashchange);
  },
  
  // activates the tab represented by the hash
  hashchange: function() {
    var hash = window.location.hash;
    this.activate(hash === '' || hash === '#' ? 
               this.element.find("li:first") : 
               this.element.find("a[href=" + hash + "]")
        .parent())
  }
});

$.pluginMaker(Jptr.HistoryTabs);