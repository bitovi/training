
		<script type='text/javascript'>
			steal.plugins("pui/list",
				"jquery/model",
				"jquery/dom/fixture").then(function(){
				
				$.Model.extend("Alert",{
					id: "alertID",
					findAll : function(params, success){
						$.get("/ss/services/alerts",
							params,
							this.callback(["wrapMany", success]),
							"json",
							"//pui/list/fixtures/alerts.json.get")
					}
				},{})
				
				$("#list").pui_list({
					model : Alert,
					template : "//pui/list/views/alert.ejs"
				})
				$('#list').bind('selected', function(ev, alrt){
					$("#out").html(alrt.eventName)
				})
			}).start();
		</script>
		
		
		
	$.Controller.extend("Pui.List",{
		init : function(el){
			this.options.model.findAll({},
				this.callback('list'))
			
		},
		list : function(items){
			this.element.html("//pui/list/views/list.ejs",{
				items : items,
				template : this.options.template
			})
		},
		"tr click" : function(el, ev){
			el.trigger("selected",el.model());
		}
	})
	
	
	list.ejs
	
	<table>
	<%for(var i =0; i < items.length; i++){%>
	 <tr <%= items[i]%> class='selectable'>
	 	<%= $.View(template, items[i])%>
	 </tr>
	<%}%>
</table>