// version 1
$.fn.tabs = function(){
	var lis = this.find('li:nth-child(n+2)');
	lis.each(function(i, li){
		var href = $(li).children().attr("href");
		$(href).hide();
	})
	this.find('li:nth-child(1)').addClass('active');
	this.find('li').bind("click", function(){
		$('.active').removeClass('active');
		var href = $(this).addClass("active").children().attr("href");
		$("div").hide();
		$(href).show();
	})
}

// version 2: refactored
/*
(function() {
      // returns the tab content for a tab
      var tab = function(li){
	  	return $(li.find("a").attr("href"))
	  },
      // deactivates the old active tab, marks the li as active
      activate = function(li) {
          tab(li.siblings('.active').removeClass('active')).hide()
          tab(li.addClass('active')).show();
      },
      // activates the tab on click
      tabClick = function(ev) {
          activate($(ev.currentTarget))
      }
      // a simple tab plugin
      $.fn.tabs = function(){
	  
	  	this.each(function(){
	  		var el = $(this);
	  		
	  		el.addClass("tabs").delegate("li", "click", tabClick).children("li:gt(0)").each(function(){
	  			tab($(this)).hide();
	  		});
	  		
	  		activate(el.children("li:first"))
	  	})
	  }
})();
*/