steal.plugins('steal/less','jquery/controller',
			'jquery/model',
			'jquery/view/ejs').then(
			function(){
				steal.less('list')
			},
			function($){
	$.Controller("Pui.List",{
		defaults: {
			model: null,
			template: "//pui/list/views/row.ejs",
			params: {}
		}
	}, {
		init: function(el){
			this.options.model.findAll(this.options.params, this.callback('list'))
		},
		list: function(testers){
			this.element.html("//pui/list/views/list.ejs", {
				testers: testers,
				template: this.options.template
			})
		},
		// on tr click, publish selected event with model instance
		"tr click": function(el, ev){
			el.trigger("selected", el.model())
		}
	})
});