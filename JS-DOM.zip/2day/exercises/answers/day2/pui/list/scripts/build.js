//steal/js pui/list/scripts/compress.js

load("steal/rhino/steal.js");
steal.plugins('steal/build','steal/build/scripts','steal/build/styles',function(){
	steal.build('pui/list/scripts/build.html',{to: 'pui/list'});
});
