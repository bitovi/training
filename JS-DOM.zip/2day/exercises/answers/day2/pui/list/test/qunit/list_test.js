module("list");

test("list testing works", function(){
	ok(true,"an assert is run");
});