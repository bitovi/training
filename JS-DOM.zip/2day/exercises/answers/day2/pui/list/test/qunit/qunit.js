steal
  .plugins("funcunit/qunit", "pui/list")
  .then("list_test");