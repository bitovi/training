test("model",function(){
	expect(3);
	stop();
	Model("Person",{
	  speak : function(){
	  	ok(this.name, "person has a name")
	    return "I am "+this.name+".";
	  }
	});
	
	Person.findOne(5, function(person){
	  ok(person.speak, "person has a speak method")
	  person.speak();
	});
	
	Model("Task")
	
	Task.findOne(7,function(task){
	  ok(task.name, "task has a name")
	})
})