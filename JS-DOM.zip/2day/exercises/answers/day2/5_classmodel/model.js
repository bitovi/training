$.Class("Model",{
  // request data/tasks/5
  findOne : function(id, success){
    $.get('data/'+this.fullName.toLowerCase()+'/'+id+'.json', 
      this.callback(function(attrs){
         success( new this( attrs ) );
      }), 'json')
  }
},{
  init : function(attrs){
    $.extend(this, attrs)
  }
})