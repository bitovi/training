test("query strings as selectors",function(){
	var inputs = baby$(".myinput");
	ok(inputs.length, 3, "3 elements found")
	inputs.val("abc")
	equals(inputs[1].value, "abc", "value set")
})

test("find",function(){
	var bar = baby$(".foo").find(".bar");
	equals(bar.length, 2, "2 elements found")
})

test("traversers", function(){
	var bar = baby$(".foo").children()
	equals(bar.length, 2, "2 elements found")
	
	var foo = baby$(".bar").parent()
	equals(foo.length, 1, "element found")
	
	var next = baby$(".prev").next()
	equals(next[0].className, "next", "element found")
	
	var prev = baby$(".next").prev()
	equals(prev[0].className, "prev", "element found")
})

test("attr", function(){
	baby$("#age").attr("class","active")
	equals(baby$("#age")[0].className, "active", "setter works")
	equals(baby$("#age").attr("name"), "user[age]", "getter works")
})

test("css", function(){
	baby$("#age").css("padding","5px")
	var padding = baby$("#age").css("padding-left"); 
	equals(padding, "5px", "setter and getter work")
})

test("width", function(){
	var width = baby$(".foo").width();
	equals(width, 100, "width is correct")
})
