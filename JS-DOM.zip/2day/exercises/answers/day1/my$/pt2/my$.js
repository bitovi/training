(function(){

	my$ = function( selector ) {
		if(this.constructor !== my$){
			return new my$(selector);
		}

		var elements;
		if( typeof selector === 'string' ) {
			elements = document.querySelectorAll(selector);
		} else if( selector.length ){
			elements = selector;
		} else {
			elements = [selector];
		}

		this.length = 0;
		[].push.apply(this, my$.makeArray( elements ) ); //[Element1, Element2, Element3]
	}

	my$.makeArray = function(arraylike){
		var arr = [];
		for(var i = 0; i < arraylike.length; i++){
			arr[i] = arraylike[i]
		}
		return arr;
	}

	var getAndSet = function(name, get, setter){
		my$.prototype[name] = function(newVal){
			if( arguments.length >= setter.length  ){
				for(var i =0; i < this.length; i++){
					setter.apply(this[i], arguments)
				}
				return this;
			} else {
				return get.apply(this[0], arguments)
			}
		}
	};

	getAndSet("val",
		function(){
			return this.value
		},
		function( newVal){
			this.value = newVal;
		});

	getAndSet("html",
		function(){
			return this.innerHTML
		},
		function(newHTML){
			this.innerHTML = newHTML;
		});

	var getTextNodes = function(el, callback){
		var childNodes = el.childNodes;
		for(var i =0; i < childNodes.length; i++){
			var childNode = childNodes[i];
			if(childNode.nodeType === 3){
				callback(childNode.nodeValue)
			} else {
				getTextNodes(childNode, callback)
			}
		}
	}

	getAndSet("text",
		function(){
			var text = "";
			getTextNodes(this, function(txt){
				text =  text + txt
			});
			return text;
		},
		function( newText){
			this.innerHTML ="";
			var textNode = document.createTextNode(newText);
			this.appendChild(textNode);
		});

	my$.prototype.find = function(selector){
		return my$( this[0].querySelectorAll(selector) )
	}

	my$.prototype.children = function(){
		var el = this[0],
			arr = [],
			children = el.childNodes;
		for(var i =0; i < children.length; i++){
			if(children[i].nodeType === 1){
				arr.push(children[i])
			}
		}
		return new my$( arr );
	};

	my$.prototype.parent = function(){
		return new my$([this[0].parentNode])
	}

	my$.prototype.next = function(){
		var current = this[0].nextSibling;
		while(current && current.nodeType !== 1){
			current = current.nextSibling;
		}

		return new my$(current ? [current] : []);
	}
	my$.prototype.prev = function(){
		var current = this[0].previousSibling;
		while(current && current.nodeType !== 1){
			current = current.previousSibling;
		}

		return new my$(current ? [current] : []);
	}

	getAndSet("attr",
		function(attrName){
			return this.getAttribute(attrName)
		},
		function(attrName, attrValue){
			return this.setAttribute(attrName, attrValue)
		})

	getAndSet("css",
		function(styleProp){
			return document
				.defaultView
				.getComputedStyle( this, null )
				.getPropertyValue( styleProp )
		},
		function(styleProp, styleValue){
			return this.style[styleProp] = styleValue;
		})

	my$.prototype.width = function(){
		var el = this[0],
			self = this,
			getCssVal = function(val){
				return parseInt(self.css(val) || 0, 10)
			},
			total = el.clientWidth,
			padding = getCssVal("padding-left") + getCssVal("padding-right"),
			border = getCssVal("border-left") + getCssVal("border-right"),
			width = total - padding - border;
		return width;
	}
})()