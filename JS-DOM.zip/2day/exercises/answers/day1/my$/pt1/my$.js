(function(){

	my$ = function( selector ) {
		this.element = document.getElementById(selector.substring(1));
	}

	var getAndSet = function(name, get, setter){
		my$.prototype[name] = function(newVal){
			if( arguments.length >= setter.length  ){
				setter.apply(this.element, arguments)
				return this;
			} else {
				return get.apply(this.element, arguments)
			}
		}
	};

	getAndSet("val", 
		function(){
			return this.value
		},
		function( newVal){
			this.value = newVal;
		});

	getAndSet("html", 
		function(){
			return this.innerHTML
		},
		function(newHTML){
			this.innerHTML = newHTML;
		});

	var getTextNodes = function(el, callback){
		var childNodes = el.childNodes;
		for(var i = 0; i < childNodes.length; i++){
			var childNode = childNodes[i];
			if(childNode.nodeType === 3){
				callback(childNode.nodeValue)
			} else {
				getTextNodes(childNode, callback)
			}
		}
	}

	getAndSet("text", 
		function(){
			var text = "";
			getTextNodes(this, function(txt){
				text = text + txt
			});
			return text;
		},
		function(newText){
			this.innerHTML = "";
			var textNode = document.createTextNode(newText);
			this.appendChild(textNode);
		});

})()