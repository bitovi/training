test("val",function(){
	var age = new my$("#age");
	ok(age.element, "an element was found")
	age.val(28)
	equals(age.element.value, 28, "setter works correctly")
	equals(age.val(), 28, "getter works correctly")
})

test("html",function(){
	var div = new my$("#mydiv");
	div.html("hello world")
	equals(div.element.innerHTML, 'hello world', "setter works correctly")
	equals(div.html(), 'hello world', "getter works correctly")
})

test("text",function(){
	var div = new my$("#sometext");
	ok(div.text(), 'This is a bunch of random text', "getter works correctly")
	div.text("changed text")
	ok(div.text(), 'changed text', "setter works correctly")
})