(function(){

	my$ = function( selector ) {
		if(this.constructor !== my$) {
			return new my$(selector);
		}

		var elements;
		if(typeof selector === 'string') {
			elements = document.querySelectorAll(selector);
		}
		else if(selector.length) {
			elements = selector;
		}
		else {
			elements = [selector];
		}

		this.length = 0;
		[].push.apply(this, elements);
	}

	my$.prototype.find = function(selector) {
		return my$(this[0].querySelectorAll(selector));
	}

	my$.prototype.next = function() {
		//nodeType === 1 -> htmlelement
		var current = this[0].nextSibling;
		while(current && current.nodeType !== 1) {
			current = current.nextSibling;
		}

		return my$(current ? current : []);
	}

	my$.prototype.prev = function() {
		//nodeType === 1 -> htmlelement
		var current = this[0].previousSibling;
		while(current && current.nodeType !== 1) {
			current = current.previousSibling;
		}

		return my$(current ? current : []);
	}

	my$.prototype.parent = function() {
		return my$(this[0].parentNode);
	}

	my$.prototype.children = function() {
		var nodes = [];

		for(var i = 0; i < this[0].childNodes.length; i++) {
			var node = this[0].childNodes[i];

			if(node.nodeType === 1) {
				nodes.push(node);
			}
		}

		return my$(nodes);
	}

	var getAndSet = function(name, get, setter){
		my$.prototype[name] = function(newVal){
			if( arguments.length >= setter.length  ){
				for(var i = 0; i < this.length; i++) {
					setter.apply(this[i], arguments);
				}

				return this;
			} else {
				return get.apply(this[0], arguments)
			}
		}
	};

	my$.prototype.width = function() {
		//get css width prop
		//clientWidth - left padding - right padding
		var total = this[0].clientWidth,
		padding = parseInt(this.css('padding-left'), 0) +
			parseInt(this.css('padding-right'), 0);

		return total - padding;
	}

	getAndSet("attr", function(name){
		return this.getAttribute(name);
	}, function(name, val) {
		return this.setAttribute(name, val);
	});

	getAndSet("css", function(name) {
		return document
			.defaultView
			.getComputedStyle(this, null)
			.getPropertyValue(name);
	}, function(name, val) {
		return this.style[name] = val;
	});

	getAndSet("val", 
		function(){
			return this.value
		},
		function( newVal){
			this.value = newVal;
		});

	getAndSet("html", 
		function(){
			return this.innerHTML
		},
		function(newHTML){
			this.innerHTML = newHTML;
		});

	var getTextNodes = function(el, callback){
		var childNodes = el.childNodes;
		for(var i = 0; i < childNodes.length; i++){
			var childNode = childNodes[i];
			if(childNode.nodeType === 3){
				callback(childNode.nodeValue)
			} else {
				getTextNodes(childNode, callback)
			}
		}
	}

	getAndSet("text", 
		function(){
			var text = "";
			getTextNodes(this, function(txt){
				text = text + txt
			});
			return text;
		},
		function(newText){
			this.innerHTML = "";
			var textNode = document.createTextNode(newText);
			this.appendChild(textNode);
		});

	my$.prototype.each = function(callback) {
		//loop through each item in our array
		//execute the callback for each item
		for(var i = 0; i < this.length; i++) {
			callback.call(this[i], i, this[i]);
		}
	}

	my$.prototype.bind = function(event, callback) {
		//loop through each item and add an event listener
		this.each(function(i, item) {
			item.addEventListener(event, callback, false);
		});

		return this;
	}

	my$.prototype.show = function() {
		this.each(function(i, item) {
			my$(item).css('display', '');
		});
	}

	my$.prototype.hide = function() {
		this.each(function(i, item) {
			my$(item).css('display', 'none');
		});
	}

	my$.fn = my$.prototype;
})()






/*
(function(){
	
	my$ = function( selector ) {
		if(this.constructor !== my$){
			return new my$(selector);
		}
		var elements;
		if( typeof selector === 'string' ) {
			elements = document.querySelectorAll(selector);
		} else if( selector.length ){
			elements = selector;
		} else {
			elements = [selector];
		}
	
		this.length =0;
		[].push.apply(this, my$.makeArray( elements )  ); //[Element1, Element2, Element3]
	}
	my$.makeArray = function(arraylike){
		var arr = [];
		for(var i =0; i < arraylike.length; i++){
			arr[i] = arraylike[i]
		}
		return arr;
	}
	var getAndSet = function(name, get, setter){
		my$.prototype[name] = function(newVal){
	
			if( arguments.length >= setter.length  ){
				for(var i =0; i < this.length; i++){
					setter.apply(this[i], arguments)
				}
				return this;
			} else {
				return get.apply(this[0], arguments)
			}
		}
	};
	getAndSet("val", 
		function(){
			return this.value
		},
		function( newVal){
			this.value = newVal;
		});
	
	getAndSet("html", 
		function(){
			return this.innerHTML
		},
		function(newHTML){
			this.innerHTML = newHTML;
		});
	
	var getTextNodes = function(el, callback){
		var childNodes = el.childNodes;
		for(var i =0; i < childNodes.length; i++){
			var childNode = childNodes[i];
			if(childNode.nodeType === 3){
				callback(childNode.nodeValue)
			} else {
				getTextNodes(childNode, callback)
			}
		}
	}
	
	getAndSet("text", 
		function(){
			var text = "";
			getTextNodes(this, function(txt){
				text =  text + txt
			});
			return text;
		},
		function( newText){
			this.innerHTML ="";
			var textNode = document.createTextNode(newText);
			this.appendChild(textNode);
		});
		
	my$.prototype.find = function(selector){
		return my$( this[0].querySelectorAll(selector) )
	}
	
	my$.prototype.children = function(){
		var el = this[0],
			arr = [],
			children = el.childNodes;
		for(var i =0; i < children.length; i++){
			if(children[i].nodeType === 1){
				arr.push(children[i])
			}
		}
		return new my$( arr );
	};
	
	my$.prototype.parent = function(){
		return new my$([this[0].parentNode])
	}	
	my$.prototype.next = function(){
		var current = this[0].nextSibling;
		while(current && current.nodeType !== 1){
			current = current.nextSibling;
		}
	
		return new my$(current ? [current] : []);
	}
	my$.prototype.prev = function(){
		var current = this[0].previousSibling;
		while(current && current.nodeType !== 1){
			current = current.previousSibling;
		}
	
		return new my$(current ? [current] : []);
	}
	
	getAndSet("attr", 
		function(attrName){
			return this.getAttribute(attrName)
		},
		function(attrName, attrValue){
			return this.setAttribute(attrName, attrValue)
		})
		
	getAndSet("css", 
		function(styleProp){
			return document
	                  .defaultView
	                  .getComputedStyle( this, null )
	                  .getPropertyValue( styleProp ) 
		},
		function(styleProp, styleValue){
			return this.style[styleProp] = styleValue;
		})
	my$.prototype.width = function(){
		var el = this[0],
			self = this,
			getCssVal = function(val){
				return parseInt(self.css(val) || 0, 10)
			},
			total = el.clientWidth,
			padding = getCssVal("padding-left") + getCssVal("padding-right"),
			border = getCssVal("border-left") + getCssVal("border-right"),
			width = total - padding - border;
		return width;
	}
	
	my$.prototype.each = function(callback){
		for(var i =0; i < this.length; i++){
			callback.call(this[i], i, this[i])
		}
	}
	
	my$.prototype.bind = function(event, callback){
		this.each(function(i, el){
			el.addEventListener(event, callback, false)
		})
		return this;
	}
	
	my$.fn = my$.prototype;
	my$.fn.addClass = function(className){
		this.each(function(i, el){
			this.className = className;
		})
		return this;
	}
	my$.fn.removeClass = function(){
		this.each(function(i, el){
			this.className = '';
		})
		return this;
	}
	my$.fn.show = function(){
		return this.css('display','')
	}
	my$.fn.hide = function(){
		return this.css('display','none')
	}
	
})()
//*/