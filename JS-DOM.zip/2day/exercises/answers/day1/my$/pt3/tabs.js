my$.fn.tabs = function(){
	var lis = this.find('li:nth-child(n+2)');
	lis.each(function(i, li){
		var href = my$(li).children().attr("href");
		my$(href).hide();
	})
	this.find('li:nth-child(1)')//.addClass('active');
	this.find('li').bind("click", function(){
		//my$('.active').removeClass('active');
		var href = my$(this)/*.addClass("active")*/.children().attr("href");
		my$("div").hide();
		my$(href).show();
	})
}