test("each",function(){
	var count = 0;
	baby$('.bar').each(function(i, el){
		count++;
	})
	equals(count, 2, "each was run twice")
})

test("bind",function(){
	expect(1)
	var input = baby$("#age"); 
	input.bind("focus", function(){
		ok(true, "change triggered")
	})
	.val("abc")
	input[0].focus();
})

test("show/hide", function(){
	var foo = baby$(".foo")
	foo.hide()
	equals(foo.css("display"), "none", "hide works")
})