$.fn.tabs = function(){
	var lis = this.find('li:nth-child(n+2) a');

	lis.each(function(i, item) {
		var href = $(item).attr('href');
		$(href).hide();
	});

	this.find('li').bind('click', function() {
		var href = $(this).children().attr('href');
		$('div').hide();
		$(href).show();
	})
}