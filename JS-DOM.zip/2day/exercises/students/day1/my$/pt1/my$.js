(function(){

	my$ = function() {}

})()