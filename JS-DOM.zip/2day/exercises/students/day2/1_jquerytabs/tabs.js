// version 1
$.fn.tabs = function(){
	
}

// version 2: refactored
/*
(function() {
      // a simple tab plugin
      $.fn.tabs = function(){
      	
	  }
})();
*/