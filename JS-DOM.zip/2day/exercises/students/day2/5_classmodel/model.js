$.Class("Model",{
	
})