Jptr.HistoryTabs = function(el, options) {
	
};