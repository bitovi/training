Jptr = {};

Jptr.Tabs = function(el, options) {
	
}
  $.extend(Jptr.Tabs.prototype, {
   
    // the name of the plugin
    name: "jptr_tabs",
    
    // Sets up the tabs widget
    init: function(el, options) {
		
    }
});
$.pluginMaker(Jptr.Tabs);