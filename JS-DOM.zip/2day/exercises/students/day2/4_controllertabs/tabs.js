// create a new Tabs class
$.Controller("Tabs",{
	
})