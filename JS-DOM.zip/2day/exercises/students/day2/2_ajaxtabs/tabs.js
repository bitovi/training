$.fn.tabs = function(){
	
}