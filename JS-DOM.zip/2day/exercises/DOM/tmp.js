

delete me.name;

name.first //-> "Justin"
