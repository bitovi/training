// 05 Context
DOT = function(obj, prop){

}

// 05 Context
DOTCALL = function(obj, prop, args){

}

// 06 Prototypes
NEW = function(constructor, args){

}

INSTANCEOF = function(obj, constructor){

}