events = [
    'click',
	'dblclick',
	'mousedown', 	
	'mouseup', 	
	'mouseover', 	
	'mouseout', 
	'mousemove', 
	'contextmenu',
	'select', 	
	'change', 	
	'submit', 	
	'reset', 	
	'focus', 	
	'blur', 	
	'scroll', 	
	'keydown', 	
	'keypress', 	
	'keyup' 
];


window.addEventListener("load", function(event){
	
	jQuery.each(events, function(i, event_name){
		var elements = document.getElementsByClassName(event_name)
		jQuery.each(elements, function(j, element){
			element.addEventListener(event_name, function(event){
				console.log(event_name, this, event)
				$('#'+event_name+'ed').css({backgroundColor: "#008000"}).animate({backgroundColor: "#80ff80"});
			},false)
		})
		
	})
	
	console.log("load", this, event)
	$('#loaded').css({backgroundColor: "#00ff00"}).animate({backgroundColor: "#80ff80"});
	
	$('h2').click(function(){
			var self = this;
			$.scrollTo(this, 800, function(){
				$(self).next().slideDown('slow');
			})
			//document.body.scrollTop = $(this).offset().top;
			
		})
	
}, false);

$(window).resize(function(event){
	console.log("resize", this, event)
	$('#resizeed').css({backgroundColor: "#00ff00"}).animate({backgroundColor: "#80ff80"});
})

$(window).ready(function(event){
	console.log("ready", this, event)
	$('#readyed').css({backgroundColor: "#00ff00"}).animate({backgroundColor: "#80ff80"});
})

/*some_callback_function = function(element, event){
	console.log(element, event)
}*/
callback_function = function(event){
	console.log(this, event)
}



var i = 0;
$("#outer").mouseover(function(){
      $("p:first",this).text("mouse over");
      $("p:last",this).text("OVER COUNT " +(++i));
	  this.style.backgroundColor = 'red'
    }).mouseout(function(){
		this.style.backgroundColor = ''
      $("p:first",this).text("mouse out");
    });

move = function(event){ document.body.scrollTop = document.body.scrollTop+ event.clientY };
say = function(event){ alert(String.fromCharCode(event.charCode )) }
enable1 = function(e){
	if(e.innerHTML == "Enable"){
		document.addEventListener('click',move , false);
		e.innerHTML = "Disable"
	}else{
		document.removeEventListener('click',move , false);
		e.innerHTML = "Enable"
	}
}
enable2 = function(e){
	if(e.innerHTML == "Enable"){
		document.addEventListener('keypress',say  , false);
		e.innerHTML = "Disable"
	}else{
		document.removeEventListener('keypress', say , false);
		e.innerHTML = "Enable"
	}
}
$('#prevent_mousedown').mousedown(function(e){e.preventDefault()});
/*$('#prevent_keydown').keydown(function(e){e.preventDefault()});
$('#prevent_keypress').keypress(function(e){e.preventDefault()});
$('#prevent_keyup').keyup(function(e){e.preventDefault()})*/
/*
 * 
 	document.getElementById('click').addEventListener("click", function(event){
		$('#clicked').css({
			backgroundColor: "red"
		}).animate({backgroundColor: "#80ff80"});
	},false)
 * 
 */