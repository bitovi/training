(function(){
	
$ = function(selector) {

};

$.extend = function(target, object){};
// Static helpers

var isArrayLike = function(obj){}

// Static methods
$.extend($ ,{
	isArray: function( obj ){ },
	each: function(collection, cb){  },
	makeArray: function(arr){  },
	proxy: function(fn, context){  }
});

$.extend($.prototype,{
	val: function( newVal ) { },
	html: function( newHtml ) { },
	text: function( newText ){ },
	find: function( selector ){ },
	children: function( selector ){ },
	parent: function( selector ){ },
	next: function(){ },
	prev: function(){ },
	attr: function( attrName, value ){ },
	css: function( cssPropName, value ){ },
	width: function(){ },
	offset : function(){ },
	hide: function(){ },
	show: function(){ },
	// Events
	bind: function(eventName, handler){ },
	unbind: function(eventName, handler){ },
	has: function(){ },
	delegate: function(selector, eventType, handler) { },
	undelegate: function(selector, eventType, handler){ },
	data: function(propName, data){ },
	// Extra
	addClass: function(className){ },
	removeClass: function(className){ },
	append: function(element){ }
});

$.buildFragment = function(html){ }

})();
